#!/bin/sh 
#

# TI sta per tempo impiegato. Queste variabili servono per calcolare il tempo impiegato dallo script
TI_INIZIO_ORA=$(/usr/bin/date +%H)
TI_INIZIO_ORA=23
TI_INIZIO_MINUTI=$(/usr/bin/date +%M)
TI_INIZIO_SECONDI=$(/usr/bin/date +%S)

sleep 57

# TI sta per tempo impiegato. Queste variabili servono per calcolare il tempo impiegato dallo script
TI_FINE_ORA=$(/usr/bin/date +%H)
TI_FINE_MINUTI=$(/usr/bin/date +%M)
TI_FINE_SECONDI=$(/usr/bin/date +%S)

echo $TI_INIZIO_ORA $TI_INIZIO_MINUTI $TI_INIZIO_SECONDI $TI_FINE_ORA $TI_FINE_MINUTI $TI_FINE_SECONDI
TI_INIZIO_SECTOT=`echo $TI_INIZIO_ORA $TI_INIZIO_MINUTI $TI_INIZIO_SECONDI | awk '{ print ($1*3600+$2*60+$3); }'`
TI_FINE_SECTOT=`echo $TI_FINE_ORA $TI_FINE_MINUTI $TI_FINE_SECONDI | awk '{ print ($1*3600+$2*60+$3); }'`
echo $TI_INIZIO_SECTOT $TI_FINE_SECTOT
TI_SEC_IMPIEGATI=`echo $TI_INIZIO_SECTOT $TI_FINE_SECTOT | awk '{ secimp=($2-$1); if (secimp < 0) { secimp=secimp+86400; }; print secimp; }'`
echo $TI_SEC_IMPIEGATI  > cancellami.prova.tempo.impiegato
#echo $TI_INIZIO_ORA $TI_INIZIO_MINUTI $TI_INIZIO_SECONDI $TI_FINE_ORA $TI_FINE_MINUTI $TI_FINE_SECONDI | awk '{ print (($4*60+$5)-($1*60+$2))*60+$6-$3; }' 

exit 0

