#!/bin/sh 

. /home/sybase/.profile

. /sis/SIS-AUX-Envsetting.Sybase.sh

# Parametri ritornati da SIS-AUX-Envsetting.Sybase.sh
# UTILITY_DIR
# SAUSER
# SAPWD
# NOTSAUSER
# NOTSAPWD
# ASE_NAME



cd /sybase/utility

ITER=3
ERRORE=1
while [ $ITER -gt 0 ] && [ $ERRORE -gt 0 ] ; do
   echo ITER=$ITER
   echo ERRORE=$ERRORE
   echo qui eseguo
   if [ $ITER -eq 2 ] ; then 
      ERRORE=0
   fi
   ITER=`expr $ITER - 1` 
   echo fine ciclo  ITER=$ITER  ERRORE=$ERRORE 
done

exit 0;

