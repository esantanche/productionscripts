#!/usr/bin/perl -w

# Prove per data di ieri

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday) = localtime(time);

$annomesegiorno = (((($year+1900) * 10000) + ($mon+1) * 100) + $mday);

print "oggi=",$annomesegiorno,"\n\n" ;

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday) = localtime(time-(24*60*60));

$annomesegiorno = (((($year+1900) * 10000) + ($mon+1) * 100) + $mday);


print "ieri=",$annomesegiorno,"\n\n"  ;

