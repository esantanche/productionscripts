#!/bin/sh -x
#

PORT=9000

echo "-------------------- lauching SIS server on port " $PORT  

nohup perl SIS-server.pl $PORT >/dev/null &

echo "-------------------- lauched"  



