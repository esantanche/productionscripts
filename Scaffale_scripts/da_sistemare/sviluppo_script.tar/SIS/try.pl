#!/usr/bin/perl -w

# SIS V. 2.0


use IO::Socket;
use IO::File;
use Net::hostent;              # for OO version of gethostbyaddr

#print gethostent;
print gethostbyaddr("127.0.0.1");
print "\n";
print $?;