#!/usr/bin/perl -w

# SIS: Client che manda mail se trova errori o warning

use strict;
use IO::Socket;
my ($host, $port, $server, $msg, $mysock, $areply, $errore, $warn);
unless (@ARGV == 2) { die "usage: $0 host port" }
($host, $port) = @ARGV;

system("title " . $host);

while (1) {

   # system("cls");

   $errore = "false";

   # create a tcp connection to the specified host and port
   $server = IO::Socket::INET->new(Proto     => "tcp", PeerAddr  => $host, PeerPort  => $port)
         or $errore="true";
   if ($errore =~ "true") {
      print "ERRORE: non riesco a collegarmi al SIS-server, host: $host\n";
      die "ERRORE non riesco a collegarmi al SIS-server porta $port su $host: $!";
   } 
   #print "server", $server;
   $server->autoflush(1);              # so output gets there right away
   #print STDERR "[Checking $host:$port]\n";
   print $server $msg;
   print $server "\n";
   $errore = "false";
   $warn = "false";
   while ( <$server> ) {
      if (/^BEGIN/) { next; }
      if (/END/) { last; }
      print $_;
      if (/err/i) { $errore = "true"; }
      if (/warn/i) { $warn = "true"; }
   } 
   #print "END (chiusura client)\n";
   close $server;

   if ($errore =~ "true") { 
       print "!!!!!!!!!!! ERRORE RICEVUTO\n"; }
   if ($warn =~ "true") { print "!!!!!!!!!!! WARNING RICEVUTO\a\n"; }
   #if ($errore =~ "true") { system ( "c:\\emanuele\\odetojoy.mid" ) ; }
   #if ($warn =~ "true") { system ( "C:\\WINNT\\Media\\notify.wav" ) ; }
   # close $areply; close $server; close $mysock; exit; 

   #if ($errore =~ "true") { system ( "C:\\Programmi\\Winamp\\winamp.exe c:\\emanuele\\odetojoy.mid" ) ; }
   #if ($warn =~ "true") { system ( "C:\\Programmi\\Winamp\\winamp.exe C:\\WINNT\\Media\\notify.wav" ) ; }

   if ($msg =~ "shutdown") {
      #print "ERRORE: non riesco a collegarmi al SIS-server, host: $host\n";
      last;
   } 
   sleep 60;
   system("cls");
   sleep 8;
}