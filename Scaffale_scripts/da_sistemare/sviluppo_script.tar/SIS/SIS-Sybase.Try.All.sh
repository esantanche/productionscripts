#!/bin/sh -x
#

# Parametri di personalizzazione della procedura
PWD=captstpwd
ASE_NAME=MX2_TEST_1

DATA=$(/usr/bin/date +%Y%m%d)

echo "----------------------------------------------------------------" > /tmp/tempinfoout 
echo "NOME ASE: "$ASE_NAME >> /tmp/tempinfoout 

echo "HOSTNAME: "$(hostname) >> /tmp/tempinfoout
echo "IFCONFIG" >> /tmp/tempinfoout
ifconfig -a >> /tmp/tempinfoout
echo "----------------------------------------------------------------" >> /tmp/tempinfoout 

echo "----------------------------------------------------------------" >> /tmp/tempinfoout 
echo "LISTA SCRIPTS /sybase/utility" >> /tmp/tempinfoout 
ls -al /sybase/utility  >> /tmp/tempinfoout 
ls -al /usr/bin/backup* >> /tmp/tempinfoout
awk '{ system("ls -al " $1) ; }' /info/relevant-files-list  >> /tmp/tempinfoout

# comandi informativi Sybase

/usr/bin/su - sybase -c isql -Usa -P$PWD -S$ASE_NAME -w1000 -o /tmp/tempisqlout << EOF
select getdate()
go
select "VERSIONE" as "--------------------"
go
select @@version
go
select "HELPSERVER" as "--------------------"
go
sp_helpserver
go
select "HELPDB" as "--------------------"
go
sp_helpdb
go
select "HELPDEVICE" as "--------------------"
go
sp_helpdevice
go
select "LOGINS" as "--------------------"
go
select name,dbname,suid from syslogins
go
select "MEMORY USE" as "--------------------"
go
sp_configure "Memory Use"
go
select "ALL CONFIGURE" as "--------------------"
go
sp_configure 
go
EOF

cat /tmp/tempisqlout >> /tmp/tempinfoout

echo "--------------------" >> /tmp/tempinfoout 
echo "SVMON in pagine da 4K" >> /tmp/tempinfoout 
svmon >> /tmp/tempinfoout 

echo "--------------------" >> /tmp/tempinfoout 
echo "LOGICAL VOLUMES" >> /tmp/tempinfoout 
lsvg -l sybasevg >> /tmp/tempinfoout 
df -k >> /tmp/tempinfoout 

echo "--------------------" >> /tmp/tempinfoout 
echo "PERS LARGE FILES " `svmon -U sybase | grep 'pers large file' | awk -f /info/check-pers-file.awk - ` " mb " >>/tmp/tempinfoout

echo "--------------------" >> /tmp/tempinfoout
echo "VMTUNE parameters" >> /tmp/tempinfoout
/usr/samples/kernel/vmtune -a | awk ' /minperm%|maxperm%/ { printf "%-20s %4d %%\n", $1, $3 ; } / minperm | maxperm / { printf "%-30s %7.1f Gb\n", $1, $3*4/1000000; } /strict_maxperm/ { print $1, " - ", ($3 == '0' ? "falso" : "vero") ; }' - >> /tmp/tempinfoout

echo "---System tables bcp -------------------------------------------------------------" >> /tmp/tempinfoout

sh /info/sysbcp.sh

awk '{ print " " ; print $1,  "=========================================\n" ; system ( "cat *-" $1 ".bcp" ) ; }' /info/systables >> /tmp/tempinfoout

echo "----------------------------------------------------------------" >> /tmp/tempinfoout

cat /tmp/tempinfoout


