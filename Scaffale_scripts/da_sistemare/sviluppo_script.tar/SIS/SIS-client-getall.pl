#!/usr/bin/perl -w

# SIS: System Info Server - Ver. 1.0

use strict;
use IO::Socket;
use IO::File;

my ($host, $port, $server, $msg, $mysock, $areply, $errore, $warn, $nomevar,
    $file_risposta, $begin_trovato);
unless (@ARGV == 3) { die "usage: $0 host port nomevariabile" }
($host, $port, $nomevar) = @ARGV;

# system("title " . $host);

# system("cls");

$errore = "false";

# create a tcp connection to the specified host and port
$server = IO::Socket::INET->new(Proto     => "tcp", PeerAddr  => $host, PeerPort  => $port)
         or $errore="true";
if ($errore =~ "true") {
   print "ERRORE: non riesco a collegarmi al SIS-server, host: $host\n";
   die "ERRORE non riesco a collegarmi al SIS-server porta $port su $host: $!";
} 
#print "server", $server;
$server->autoflush(1);              # so output gets there right away
#print STDERR "[Checking $host:$port]\n";
print $server "get ", $nomevar;
print $server "\n";
$errore = "false";
$warn = "false";
$file_risposta = new IO::File;
if ($file_risposta->open("SIS-" . $host . "-" . $nomevar . ".txt","w")) {
   # while () { print $client $_; }
   $begin_trovato = "false";
   while ( <$server> ) {
      print $file_risposta $_;
      if (/ENDENDEND/) { last; }
   } 

   close $file_risposta;
}

#print "END (chiusura client)\n";
close $server;


