#!/bin/sh 

. /home/sybase/.profile

. /sis/SIS-AUX-Envsetting.Sybase.sh

# Parametri ritornati da SIS-AUX-Envsetting.Sybase.sh
# UTILITY_DIR
# SAUSER
# SAPWD
# NOTSAUSER
# NOTSAPWD
# ASE_NAME

MAILTO="dba@kyneste.com"

echo "From: daemon@mx1-dev-2.kyneste.com"
echo "To: dba@kyneste.com"
echo "Subject: prova crontab oggetto"
echo "Prova invio mail crontab prova x1907"
echo `hostname`

cd /sybase/utility

echo prima del nohup
nohup prova-tempo-impiegato.sh par1 par2 2>&1 >/dev/null &   
echo dopo il nohup

exit 0;

